Citations:
    1) https://stackoverflow.com/questions/16099694/how-to-remove-empty-string-in-a-list/16099706
       We used this simple Python trick for removing empty tokens ('') from a list.
       The trick is: list(filter(None, tokens)), where tokens is a list.